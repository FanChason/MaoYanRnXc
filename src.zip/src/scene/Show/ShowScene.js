import React, { PureComponent } from 'react'
import { Text } from 'react-native'

class ShowScene extends PureComponent {
  render() {
      return <Text>Show</Text>
    }
}

export default ShowScene;
