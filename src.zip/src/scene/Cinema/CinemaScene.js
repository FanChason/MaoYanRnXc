import React, { PureComponent } from 'react'
import { Text } from 'react-native'

class CinemaScene extends PureComponent {
  render() {
      return <Text>Cinema</Text>
    }
}

export default CinemaScene;
