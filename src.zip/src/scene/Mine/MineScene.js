import React, { PureComponent } from 'react'
import { Text } from 'react-native'

class MineScene extends PureComponent {
  render() {
      return <Text>Mine</Text>
    }
}

export default MineScene;
