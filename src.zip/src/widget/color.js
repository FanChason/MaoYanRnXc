export default {
    theme: '#06C1AE',
    border: '#e0e0e0',
    background: '#f3f3f3'
}
