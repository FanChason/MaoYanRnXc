export default {
    Idle: 'Idle',
    Refreshing: 'Refreshing',
    NoMoreData: 'NoMoreData',
    Failure: 'Failure'
}
