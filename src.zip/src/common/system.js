import { Platform } from 'react-native'

export default {
    isIOS: Platform.OS === 'ios',

}
